2356 strongly regular graphs with parameters (442,231,120,121)
===============================================================

Data of the joint paper of D. Plummer and A. Kovaľ on strongly regular graphs on 442 points.
Four graph6 files, one graph per line, 2356 graphs in all, pairwise non-isomorphic.

The graphs are the line-piece regular members (the line-piece model of the paper) of two regular two-graphs
on 442 points:
  Omega_M  Mathon's conference two-graph for q = 7 (file names "mathon");
  Omega_P  the variant whose nine fibres are copies of Paley(49) (file names "ours").
A member of degree 231 is listed as it is.  A member of degree 210 is listed by its complement, which has degree 231
and lies in the complementary two-graph.

file                                         graphs  two-graph, degree           SHA-256 of the file
koval442_ours_deg231_575.g6                     575  Omega_P, 231                46fe141c53a83fffb633659c5b7a6c0c0d68d4c1e980324a15a7d483c68ebed4
koval442_ours_deg210_complemented_603.g6        603  Omega_P, 210, complemented  8f91dba6aa6ac3930a3ffb8f334be4e59983fa08840888c1d71de7bda3829751
koval442_mathon_deg231_575.g6                   575  Omega_M, 231                ab384ab8bf074ddf4b819db90e1fc39e9fc0fdab4751f301186c0473d232f163
koval442_mathon_deg210_complemented_603.g6      603  Omega_M, 210, complemented  7e1207a4f8b8735176954fc2726a74cef7da5c438dfd6e9686d6e933d58bfde2

Each file holds exactly one graph per orbit of Aut(Omega) = C3 x C3 on the members of that degree.  Every graph
satisfies A^2 = 231 I + 120 A + 121 (J - I - A) exactly.  The programs that produced and checked these files, the
table of clique numbers and the checks are in the folder koval/ that accompanies the paper (see its README.md).
